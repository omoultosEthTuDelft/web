#!/usr/bin/env python
# Compute binding free energy for BCD-FOA, orientation 1, implicit solvent (GB).

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from paprika import analysis
from paprika.io import load_restraints

host = "BCD"
guest = "FOA"
windows_dir = "windows_nopbc1"

attach_string = "0.00 0.01 0.0375 0.40 0.80 1.60 2.40 4.00 5.50 8.65 11.80 18.10 24.40 37.00 49.60 74.80 100.00"
attach_fractions = [float(i) / 100 for i in attach_string.split()]
initial_distance = 6.0
pull_distances = np.arange(initial_distance, 14.5 + initial_distance, 0.5)

guest_restraints = load_restraints(f"{windows_dir}/restraints.json")

free_energy = analysis.fe_calc()
free_energy.topology = f"{host}-{guest}-dum.prmtop"
free_energy.trajectory = "production*.nc"
free_energy.path = windows_dir
free_energy.restraint_list = guest_restraints
free_energy.collect_data()
free_energy.methods = ["ti-block"]
free_energy.ti_matrix = "full"
free_energy.boot_cycles = 1000
free_energy.compute_free_energy()

free_energy.compute_ref_state_work([
    guest_restraints[0], guest_restraints[1], None,
    None, guest_restraints[2], None,
])

binding_affinity = -1 * (
    free_energy.results["attach"]["ti-block"]["fe"]
    + free_energy.results["pull"]["ti-block"]["fe"]
    + free_energy.results["ref_state_work"]
)
sem = np.sqrt(
    free_energy.results["attach"]["ti-block"]["sem"] ** 2
    + free_energy.results["pull"]["ti-block"]["sem"] ** 2
)

attach_fe = free_energy.results["attach"]["ti-block"]["fe_matrix"][0, :]
pull_fe = free_energy.results["pull"]["ti-block"]["fe_matrix"][0, :]
x_pull = pull_distances - 6 + attach_fractions[-1]

plt.plot(attach_fractions, attach_fe, label="attach phase")
plt.plot(x_pull, attach_fe[-1] + pull_fe, label="pull phase")
plt.plot(
    [x_pull[-1], x_pull[-1]],
    [
        attach_fe[-1].magnitude + pull_fe[-1].magnitude,
        attach_fe[-1].magnitude + pull_fe[-1].magnitude + free_energy.results["ref_state_work"].magnitude,
    ],
    label="release phase",
)
plt.ylabel("Work (kcal/mol)")
plt.legend()
plt.savefig("fe_nopbc1.jpg", dpi=400)
plt.close()

print(f"The binding affinity for {guest} and {host} = {binding_affinity.magnitude:0.2f} +/- {sem.magnitude:0.2f} kcal/mol")
