#!/bin/bash
# Full APR binding free-energy pipeline for BCD-FOA.
#
# Covers both binding orientations and both solvent models:
#   - Implicit (GB): windows_nopbc{1,2}/
#   - Explicit (PBC, TIP3P bind3p + Na+/Cl-): windows_pbc{1,2}/
#
# Required software (must be on PATH):
#   - AMBER (pmemd.cuda or set PMEMD env var)
#   - Python with: paprika, parmed, numpy, matplotlib
#
# Run from the directory containing this script:
#   bash run.sh

set -euo pipefail

HOST="BCD"
GUEST="FOA"
PMEMD="${PMEMD:-pmemd.cuda}"

# Helper: run pmemd over every window in a windows directory.
# Usage: run_windows <windows_dir> <in_file> <topology_suffix> <in_coord> <out_coord>
#   topology_suffix: "-dum-sol" for PBC, "-dum" for GB
run_windows() {
    local wdir="$1"
    local in_file="$2"
    local topo_suffix="$3"
    local in_coord="$4"
    local out_coord="$5"
    local topo="${HOST}-${GUEST}${topo_suffix}.prmtop"
    local ref="${HOST}-${GUEST}${topo_suffix}.rst7"

    for dir in "${wdir}"/*/; do
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] ${in_file} -> ${dir}"
        (
            cd "$dir"
            "$PMEMD" -O \
                -i "../../${in_file}" \
                -o production.out \
                -p "${topo}" \
                -c "${in_coord}" \
                -r "${out_coord}" \
                -ref "${ref}" \
                -x production.nc \
                -v mdvel \
                -e production.mden \
                -inf production.mdinfo \
                -frc mdfrc
        )
    done
}

# ============================================================
# STEP 1 — Setup: build complex and create APR window files
# ============================================================

# --- Orientation 1: implicit solvent ---
mv "${HOST}-${GUEST}1.pdb" "${HOST}-${GUEST}.pdb"
python setup_nopbc1.py
mv windows/ windows_nopbc1/
mv complex/ complex1/

# --- Orientation 1: explicit solvent (reuses complex1/ dummy files) ---
mv complex1/ complex/
python setup_pbc1.py
mv windows/ windows_pbc1/
mv complex/ complex1/
mv "${HOST}-${GUEST}.pdb" "${HOST}-${GUEST}1.pdb"

# --- Orientation 2: implicit solvent ---
mv "${HOST}-${GUEST}2.pdb" "${HOST}-${GUEST}.pdb"
python setup_nopbc2.py
mv windows/ windows_nopbc2/
mv complex/ complex2/

# --- Orientation 2: explicit solvent ---
mv complex2/ complex/
python setup_pbc2.py
mv windows/ windows_pbc2/
mv complex/ complex2/
mv "${HOST}-${GUEST}.pdb" "${HOST}-${GUEST}2.pdb"

# ============================================================
# STEP 2 — Minimize + equilibrate
# ============================================================

# --- PBC: minimize, then 3x short equil (production_pbc1.in), then 3x longer equil (production_pbc2.in) ---
for WDIR in windows_pbc1 windows_pbc2; do
    run_windows "$WDIR" minimize_pbc.in       "-dum-sol" "${HOST}-${GUEST}-dum-sol.rst7" minimize.rst7

    run_windows "$WDIR" production_pbc1.in    "-dum-sol" minimize.rst7      production.rst7
    run_windows "$WDIR" production_pbc1.in    "-dum-sol" production.rst7    production.rst7
    run_windows "$WDIR" production_pbc1.in    "-dum-sol" production.rst7    production.rst7

    run_windows "$WDIR" production_pbc2.in    "-dum-sol" production.rst7    production.rst7
    run_windows "$WDIR" production_pbc2.in    "-dum-sol" production.rst7    production.rst7
    run_windows "$WDIR" production_pbc2.in    "-dum-sol" production.rst7    production.rst7
done

# --- GB: minimize, then 1x short equil (production_nopbc1.in) ---
for WDIR in windows_nopbc1 windows_nopbc2; do
    run_windows "$WDIR" minimize_nopbc.in     "-dum"     "${HOST}-${GUEST}-dum.rst7"     minimize.rst7
    run_windows "$WDIR" production_nopbc1.in  "-dum"     minimize.rst7                   production.rst7
done

# ============================================================
# STEP 3 — Production
# ============================================================

# --- PBC production (10 ns/window with production_pbc3.in) ---
for WDIR in windows_pbc1 windows_pbc2; do
    run_windows "$WDIR" production_pbc3.in    "-dum-sol" production.rst7    production.rst7
done

# --- GB production ---
for WDIR in windows_nopbc1 windows_nopbc2; do
    run_windows "$WDIR" production_nopbc2.in  "-dum"     production.rst7    production.rst7
done

# ============================================================
# STEP 4 — Analysis
# ============================================================

python analysis_pbc1.py
python analysis_pbc2.py
python analysis_nopbc1.py
python analysis_nopbc2.py
