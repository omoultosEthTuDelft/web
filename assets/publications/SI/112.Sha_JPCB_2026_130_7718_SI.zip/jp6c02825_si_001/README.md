# BCD-FOA Binding Free Energy Calculation Pipeline

This directory contains a complete **APR (Attach-Pull-Release)** binding free energy calculation pipeline for the **BCD-FOA host-guest system**. The host is beta-cyclodextrin (BCD) and the guest is PFOA (perfluorooctanoic acid). The pipeline covers two binding orientations and two solvent models — GB (Generalized Born, implicit solvent) and PBC (periodic boundary conditions with explicit Bind3P water) — producing four independent free energy estimates.

## Prerequisites

- **AMBER** — `pmemd.cuda` (or set the `PMEMD` environment variable to your AMBER executable)
- **Python** with the following packages:
  - [`paprika`](https://github.com/GilsonLabUCSD/paprika) — APR restraint setup and free energy analysis
  - [`parmed`](https://parmed.github.io/ParmEd/) — AMBER topology manipulation
  - `numpy`, `matplotlib`

All commands assume you are running from this directory.

## File inventory

### Molecular input files

| File | Description |
|---|---|
| `BCD-FOA1.pdb` | Host-guest complex structure, **orientation 1** (C3 of FOA leads during pull) |
| `BCD-FOA2.pdb` | Host-guest complex structure, **orientation 2** (C7 of FOA leads — reversed) |
| `BCD.mol2` | BCD (beta-cyclodextrin) topology in Tripos Mol2 format |
| `FOA.mol2` | PFOA guest topology in Tripos Mol2 format |
| `BCD.frcmod` | BCD force field parameters (bonded and nonbonded terms for carbohydrate atom types) |
| `FOA.frcmod` | PFOA force field modification (minimal — mostly zeroed-out sections) |

### Setup scripts

| Script | Purpose |
|---|---|
| `setup_nopbc1.py` | Build vacuum complex for orientation 1, add dummy atoms, create APR windows with restraints for **GB (implicit solvent)** |
| `setup_nopbc2.py` | Same as above, but for orientation 2 (reversed guest alignment) |
| `setup_pbc1.py` | Take the vacuum complex from `setup_nopbc1.py`, solvate each window with Bind3P water (~3000 molecules) and neutralize with Na⁺/Cl⁻ for **explicit solvent** |
| `setup_pbc2.py` | Same as above, for orientation 2 |

The setup scripts produce two directory trees per run:

- **`complex/`** — intermediate vacuum system with aligned host-guest and three dummy atoms (DM1, DM2, DM3) placed along the pulling axis
- **`windows/`** — one subdirectory per APR window (`a000`–`a015` for the attach phase, `p000`–`p028` for the pull phase), each containing:
  - `disang.rest` — AMBER NMR-style restraint file with all static and guest restraints for that window
  - `BCD-FOA-dum.prmtop` / `BCD-FOA-dum.rst7` (or `-dum-sol` for PBC) — topology and coordinates

### Simulation input files (AMBER `&cntrl`)

These `.in` files control AMBER `pmemd` and are read by `run.sh` at each stage.

#### GB (implicit solvent, igb=1)

| File | Stage | Key settings |
|---|---|---|
| `minimize_nopbc.in` | Minimization | 500 SD + 1000 CG steps; dummy atoms restrained |
| `production_nopbc1.in` | Short equilibration | 20 ps (nstlim=20000, dt=0.001), SHAKE on H-bonds, Langevin thermostat |
| `production_nopbc2.in` | Production MD | 2 ns (nstlim=2000000, dt=0.001), same thermostat |

#### PBC (explicit solvent, Bind3P, igb=0)

| File | Stage | Key settings |
|---|---|---|
| `minimize_pbc.in` | Minimization | 5000 SD + 1000 CG steps; dummy atoms restrained |
| `production_pbc1.in` | Short equilibration | 1 ps (nstlim=500, dt=0.002), NPT with Monte Carlo barostat |
| `production_pbc2.in` | Longer equilibration | 100 ps (nstlim=50000, dt=0.002), NPT |
| `production_pbc3.in` | Production MD | 10 ns (nstlim=5000000, dt=0.002), NPT |

The reason PBC uses three stages of equilibration with increasing timestep is to gently relax the solvated system before collecting production data. GB uses only a single short equil because the implicit solvent model is less sensitive to initial strain.

### Analysis scripts

| Script | Input directory | Output |
|---|---|---|
| `analysis_nopbc1.py` | `windows_nopbc1/` | `fe_nopbc1.jpg` (work profile plot) + binding affinity printed to stdout |
| `analysis_nopbc2.py` | `windows_nopbc2/` | `fe_nopbc2.jpg` |
| `analysis_pbc1.py` | `windows_pbc1/` | `fe_pbc1.jpg` |
| `analysis_pbc2.py` | `windows_pbc2/` | `fe_pbc2.jpg` |

Each analysis script:

1. Loads the APR restraints from `windows_*/restraints.json`
2. Reads production trajectory data (`production*.nc`) across all windows using `paprika.analysis.fe_calc`
3. Computes free energy via **TI-block** (thermodynamic integration with block averaging) with 1000 bootstrap cycles for error estimation
4. Computes the **reference state work** for releasing the guest restraints analytically
5. Combines attach + pull + release contributions to obtain the binding affinity: $ΔG_{\text{bind}}$ = −($ΔG_{\text{attach}}$ + $ΔG_{\text{pull}}$ + $ΔG_{\text{ref-state}}$)
6. Plots the cumulative work profile as a function of the APR coordinate and saves it as a JPEG

### Master script

| File | Purpose |
|---|---|
| `run.sh` | End-to-end pipeline: setup → minimization/equilibration → production → analysis |

## Workflow

The full pipeline, as orchestrated by `run.sh`, proceeds in four stages:

### Stage 1 — Setup

For each of the two orientations, the pipeline first builds the vacuum system and creates APR windows for GB, **then** solvates those windows for PBC. The GB setup must run first because the PBC setup reuses the dummy-atom complex built by the GB setup.

```
Orientation 1:  setup_nopbc1.py  →  windows_nopbc1/
                setup_pbc1.py    →  windows_pbc1/

Orientation 2:  setup_nopbc2.py  →  windows_nopbc2/
                setup_pbc2.py    →  windows_pbc2/
```

Each setup script performs these operations:

1. **Build the vacuum complex** via tleap: load BCD and FOA mol2/frcmod files, load the complex PDB
2. **Align the pulling axis**: rotate the host-guest so the guest's pulling direction is along the z-axis (C3→C7 for orientation 1; C7→C3 for orientation 2)
3. **Add three dummy atoms** (DM1, DM2, DM3) along the z-axis behind the host. These serve as fixed anchor points for the restraint scheme — they hold the host positionally and orientationally while the guest is pulled away
4. **Define the APR restraint scheme**:
   - **Static restraints** fix the host's position and orientation via distance/angle/torsion restraints anchored to the dummy atoms
   - **Guest restraints** drive the APR coordinate: one distance, one angle, and one torsion restraint, each with attach/pull/release phases
   - The attach phase gradually ramps force constants from 0 to their final values over 17 windows
   - The pull phase translates the guest away from the host over 30 windows (6.0–20.5 Å)
   - The release phase is computed analytically (no simulation windows needed)
5. **Write per-window `disang.rest` files** containing all restraint definitions for that window
6. **For PBC setups only**: solvate each window with ~3000 Bind3P water molecules and neutralize with Na⁺/Cl⁻

### Stage 2 — Minimization and equilibration

All simulation is done **per-window** — each of the 45 windows (16 attach + 29 pull) runs independently.

**PBC windows** (more extensive equilibration because of explicit water):

1. **Minimize** with `minimize_pbc.in` — relax steric clashes while dummy atoms remain positionally restrained
2. **3× short equil** with `production_pbc1.in` — 1 ps each at dt=0.002, NPT
3. **3× longer equil** with `production_pbc2.in` — 100 ps each at dt=0.002, NPT

**GB windows** (lighter equilibration):

1. **Minimize** with `minimize_nopbc.in`
2. **1× short equil** with `production_nopbc1.in` — 20 ps at dt=0.001

### Stage 3 — Production

- **PBC**: 10 ns/window with `production_pbc3.in` (nstlim=5,000,000 at dt=0.002)
- **GB**: 2 ns/window with `production_nopbc2.in` (nstlim=2,000,000 at dt=0.001)

Trajectory frames are written every 500 steps to NetCDF files (`production.nc`).

### Stage 4 — Analysis

Each analysis script processes the production trajectories to compute the binding free energy:

1. **Collect data**: read ∂U/∂λ from all `production*.nc` trajectories across all windows
2. **TI-block integration**: numerically integrate ∂U/∂λ along the APR coordinate using the trapezoidal rule with block-averaged derivatives
3. **Reference state work**: compute the analytical free energy of releasing the guest restraints in the unbound state (Boresch-style correction)
4. **Combine**: $ΔG_{\text{bind}}$ = −($ΔG_{\text{attach}}$ + $ΔG_{\text{pull}}$ + $ΔG_{\text{ref-state}}$)
5. **Output**: a work profile plot (`fe_*.jpg`) showing cumulative work vs. APR coordinate, and the binding affinity with SEM printed to stdout

## Running

To run the entire pipeline:

```bash
./run.sh
```

To run only specific parts, you can copy the relevant lines from `run.sh`. For example, to run only the GB analysis for orientation 1 after simulations have completed:

```bash
python analysis_nopbc1.py
```

## Output

After a successful run, you will have:

- `windows_nopbc1/`, `windows_nopbc2/`, `windows_pbc1/`, `windows_pbc2/` — one directory per solvent/orientation combination, each containing the 47 window subdirectories with simulation outputs
- `fe_nopbc1.jpg`, `fe_nopbc2.jpg`, `fe_pbc1.jpg`, `fe_pbc2.jpg` — cumulative work profile plots (also printed to stdout as numerical values)
- Four independent binding affinity estimates (one per orientation × solvent combination)

## Notes

- The wall restraint added to attach windows `a000`–`a003` (via `subprocess.run` in the setup scripts) prevents premature guest dissociation before the harmonic distance restraint has built up sufficient strength. This is a standard practice in APR simulations.
- The atom indices in the wall restraint (173, 151) are specific to this BCD-FOA topology. If you change the host, guest, or alignment, these indices will need to be updated.
- The PBC solvent box size (~3000 waters) is tuned for BCD. Larger hosts may require more water to satisfy the minimum image convention.
- All four combinations (2 orientations × 2 solvent models) are independent and can be run in parallel if compute resources allow.
