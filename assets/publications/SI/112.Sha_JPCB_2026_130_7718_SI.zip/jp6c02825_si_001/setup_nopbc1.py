#!/usr/bin/env python
# Setup APR windows for BCD-FOA, orientation 1, implicit solvent (GB).
# Produces complex/ and windows/ which are renamed by run.sh.

import os
import subprocess

import numpy as np
import parmed as pmd

from paprika import restraints
from paprika.build import align, dummy
from paprika.build.system import TLeap
from paprika.io import save_restraints
from paprika.restraints.amber import amber_restraint_line
from paprika.restraints.utils import create_window_list

host = "BCD"
guest = "FOA"
data = os.getcwd()  # root dir containing mol2/frcmod/pdb files

if not os.path.isdir("complex"):
    os.makedirs("complex")

# --- Build vacuum complex with tleap ---
system = TLeap()
system.output_path = "complex"
system.pbc_type = None
system.neutralize = False
system.template_lines = [
    "source leaprc.gaff2",
    "loadamberparams frcmod.ions1lm_126_tip3p",
    f"loadamberparams {data}/{host}.frcmod",
    f"{host} = loadmol2 {data}/{host}.mol2",
    f"loadamberparams {data}/{guest}.frcmod",
    f"{guest} = loadmol2 {data}/{guest}.mol2",
    f"model = loadpdb {data}/{host}-{guest}.pdb",
    "check model",
    "savepdb model vac.pdb",
    "saveamberparm model vac.prmtop vac.rst7",
]
system.build(clean_files=False)

# --- Align the pulling axis and add dummy atoms ---
# Orientation 1: C3 leads (faces away from host opening during pull).
G1 = f":{guest}@C3"
G2 = f":{guest}@C7"

structure = pmd.load_file("complex/vac.prmtop", "complex/vac.rst7", structure=True)
aligned = align.zalign(structure, G1, G2)
aligned.save("complex/aligned.prmtop", overwrite=True)
aligned.save("complex/aligned.rst7", overwrite=True)

structure = pmd.load_file("complex/aligned.prmtop", "complex/aligned.rst7", structure=True)
structure = dummy.add_dummy(structure, residue_name="DM1", z=-6.0)
structure = dummy.add_dummy(structure, residue_name="DM2", z=-9.0)
structure = dummy.add_dummy(structure, residue_name="DM3", z=-11.2, y=2.2)
structure.save("complex/aligned_with_dummy.prmtop", overwrite=True)
structure.save("complex/aligned_with_dummy.rst7", overwrite=True)
structure.save("complex/aligned_with_dummy.pdb", overwrite=True)

dummy.write_dummy_frcmod(filepath="complex/dummy.frcmod")
dummy.write_dummy_mol2(residue_name="DM1", filepath="complex/dm1.mol2")
dummy.write_dummy_mol2(residue_name="DM2", filepath="complex/dm2.mol2")
dummy.write_dummy_mol2(residue_name="DM3", filepath="complex/dm3.mol2")

# --- Final vacuum system with dummy atoms ---
system = TLeap()
system.output_path = "complex"
system.pbc_type = None
system.neutralize = False
system.template_lines = [
    "source leaprc.gaff2",
    "loadamberparams frcmod.ions1lm_126_tip3p",
    f"loadamberparams {data}/{host}.frcmod",
    f"{host} = loadmol2 {data}/{host}.mol2",
    f"loadamberparams {data}/{guest}.frcmod",
    f"{guest} = loadmol2 {data}/{guest}.mol2",
    "loadamberparams dummy.frcmod",
    "DM1 = loadmol2 dm1.mol2",
    "DM2 = loadmol2 dm2.mol2",
    "DM3 = loadmol2 dm3.mol2",
    "model = loadpdb aligned_with_dummy.pdb",
    "check model",
    f"savepdb model {host}-{guest}-dum.pdb",
    f"saveamberparm model {host}-{guest}-dum.prmtop {host}-{guest}-dum.rst7",
]
system.build()

# --- Window setup ---
attach_string = "0.00 0.01 0.0375 0.40 0.80 1.60 2.40 4.00 5.50 8.65 11.80 18.10 24.40 37.00 49.60 74.80 100.00"
attach_fractions = [float(i) / 100 for i in attach_string.split()]
initial_distance = 6.0
pull_distances = np.arange(initial_distance, 14.5 + initial_distance, 0.5)
release_fractions = []
windows = [len(attach_fractions), len(pull_distances), len(release_fractions)]
print(f"Windows: {windows}")

# Host anchor atoms on the rigid central ridge of BCD.
H = [f":{host}@75", f":{host}@33", f":{host}@138"]
H1, H2 = [], []
for i in range(7):
    if i == 6:
        H1.append([f":{host}@142", f":{host}@127", f":{host}@129", f":{host}@12"])
        H2.append([f":{host}@127", f":{host}@129", f":{host}@12", f":{host}@14"])
    else:
        H1.append([f":{host}@{16+i*21}", f":{host}@{1+i*21}", f":{host}@{3+i*21}", f":{host}@{33+i*21}"])
        H2.append([f":{host}@{1+i*21}", f":{host}@{3+i*21}", f":{host}@{33+i*21}", f":{host}@{35+i*21}"])

D1, D2, D3 = ":DM1", ":DM2", ":DM3"

structure = pmd.load_file(f"complex/{host}-{guest}-dum.prmtop", f"complex/{host}-{guest}-dum.rst7")

# Static restraints keep host in a fixed position/orientation throughout all windows.
static_restraints = []
for masks, fc in [
    ([D1, H[0]], 10.0),
    ([D2, D1, H[0]], 100.0),
    ([D3, D2, D1, H[0]], 100.0),
    ([D1, H[0], H[1]], 100.0),
    ([D2, D1, H[0], H[1]], 100.0),
    ([D1, H[0], H[1], H[2]], 100.0),
]:
    static_restraints.append(
        restraints.static_DAT_restraint(
            restraint_mask_list=masks,
            num_window_list=windows,
            ref_structure=structure,
            force_constant=fc,
            amber_index=True,
        )
    )
for masks in H1 + H2:
    static_restraints.append(
        restraints.static_DAT_restraint(
            restraint_mask_list=masks,
            num_window_list=windows,
            ref_structure=structure,
            force_constant=10.0,
            amber_index=True,
        )
    )

# Guest restraints drive the APR coordinate: attach raises force constants,
# pull translates the guest, release lowers force constants analytically.
guest_restraints = []
for mask1, mask2, mask3, attach_tgt, attach_fc, pull_tgt in [
    (D1,  G1,   None,  6.0,   10.0,  20.0),   # distance (Å, kcal/mol/Å²)
    (D2,  D1,   G1,    180.0, 100.0, 180.0),   # angle (deg, kcal/mol/rad²)
    (D1,  G1,   G2,    180.0, 100.0, 180.0),   # torsion
]:
    r = restraints.DAT_restraint()
    r.mask1 = mask1
    r.mask2 = mask2
    if mask3:
        r.mask3 = mask3
    r.topology = structure
    r.auto_apr = True
    r.continuous_apr = True
    r.amber_index = True
    r.attach["target"] = attach_tgt
    r.attach["fraction_list"] = attach_fractions
    r.attach["fc_final"] = attach_fc
    r.pull["target_final"] = pull_tgt
    r.pull["num_windows"] = windows[1]
    r.initialize()
    guest_restraints.append(r)

# Create directories and write disang.rest for each window.
window_list = create_window_list(guest_restraints)
for window in window_list:
    if not os.path.isdir(f"windows/{window}"):
        os.makedirs(f"windows/{window}")

all_restraints = static_restraints + guest_restraints
for window in window_list:
    with open(f"windows/{window}/disang.rest", "w") as f:
        for r in all_restraints:
            line = amber_restraint_line(r, window)
            if line is not None:
                f.write(line)

save_restraints(guest_restraints, filepath="windows/restraints.json")

# Wall restraint on first 4 attach windows: prevents premature guest dissociation
# before the harmonic distance restraint has built up. Atom indices 173/151 are
# the relevant DM1 dummy and guest anchor in this BCD-FOA topology.
subprocess.run(
    r"""for file in windows/a00[0-3]/disang.rest; do
    echo -n "&rst iat= 173,151,           r1=    0.00000, r2=   6.00000, r3=   8.00000, r4=  999.00000, rk2=    10.00000, rk3=    10.00000,  &end\n" >> "$file"
    echo >> "$file"
done""",
    shell=True,
    check=True,
)

# Copy/translate structures into each window directory.
import shutil
for window in window_list:
    if window[0] == "a":
        shutil.copy(f"complex/{host}-{guest}-dum.prmtop", f"windows/{window}/{host}-{guest}-dum.prmtop")
        shutil.copy(f"complex/{host}-{guest}-dum.rst7", f"windows/{window}/{host}-{guest}-dum.rst7")
    elif window[0] == "p":
        s = pmd.load_file(f"complex/{host}-{guest}-dum.prmtop", f"complex/{host}-{guest}-dum.rst7", structure=True)
        target_diff = (
            guest_restraints[0].phase["pull"]["targets"][int(window[1:])]
            - guest_restraints[0].pull["target_initial"]
        )
        print(f"Window {window}: translating guest {target_diff.magnitude:0.1f} Å.")
        for atom in s.atoms:
            if atom.residue.name == guest.upper():
                atom.xz += target_diff.magnitude
        s.save(f"windows/{window}/{host}-{guest}-dum.prmtop", overwrite=True)
        s.save(f"windows/{window}/{host}-{guest}-dum.rst7", overwrite=True)
