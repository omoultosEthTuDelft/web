For the CIF files in _label folder, all the O atoms in the Mg-alkoxide functional groups are labelled as Te, all the nearest-neighbor C atoms in the Mg-alkoxide functional groups are labelled as Sn.

For the CIF files in the _unlabel folder, no atoms label was modified. O still labelled as O and C still labelled as C.
